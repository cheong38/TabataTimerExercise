//
//  ViewController.swift
//  TabataTimer
//
//  Created by jiu-mpr on 2014. 7. 13..
//  Copyright (c) 2014 jiu-mpr. All rights reserved.
//

import UIKit

class TabataTimerViewController: UIViewController {
    
    @IBOutlet var timeLabel: UILabel
    @IBOutlet var isExerciseStateLabel: UILabel

    var sec:Int = 0
    var centiseconds:Int = 0 {
    didSet {
        var milliSecond2d:Int = (centiseconds % 100)
        sec = centiseconds / 100
        var minuite:Int = sec / 60
        var second:Int = sec % 60
        
        if centiseconds == 0 {
//            self.view.backgroundColor = UIColor(red: 254/255.0, green: 254/255.0, blue: 255/255.0, alpha: 1.0)
            self.isExerciseStateLabel.text = "준비"
        } else if isExercise(centiseconds) {
//            self.view.backgroundColor = UIColor(red: 244/255.0, green: 255/255.0, blue: 110/255.0, alpha: 1.0)
            self.isExerciseStateLabel.text = "운동 중"
//            if (centiseconds % 100) < 50 {
//               self.view.backgroundColor = UIColor(red: 248/255.0, green: 255/255.0, blue: 178/255.0, alpha: 1.0)
//            }
        } else {
            
//            self.view.backgroundColor = UIColor(red: 144/255.0, green: 192/255.0, blue: 216/255.0, alpha: 1.0)
             self.isExerciseStateLabel.text = "휴식 중"
//            if (centiseconds % 100) < 50 {
//                self.view.backgroundColor = UIColor(red: 144/255.0, green: 192/255.0, blue: 216/255.0, alpha: 0.8)
//            }
        }
        
        self.timeLabel.text = NSString(format: "%.2d:%.2d:%.2d",minuite, second, milliSecond2d)
    }
    

    }
   
    func isExercise(sec:Int) -> Bool {
        var exerciseTrue = true
        
        if (sec % (30 * 100)) <= 20 * 100 {
            exerciseTrue = true
        } else {
            exerciseTrue = false
        }
        
        return exerciseTrue
    }
    
    var timer:NSTimer?
    @IBAction func buttonTapped(sender: UIButton) {
        if sender.selected {
            //stop
            self.timer!.invalidate()
            self.timer = nil
            self.centiseconds = 0
        } else {
            //start
            self.timer = NSTimer.scheduledTimerWithTimeInterval(0.01, target: self, selector: Selector("secondpassed:"), userInfo: nil, repeats: true)
            
        }
        sender.selected = !sender.selected
    }
    
    
    
    func secondpassed(sender:NSTimer) {
        centiseconds++

    }
    
   
}

